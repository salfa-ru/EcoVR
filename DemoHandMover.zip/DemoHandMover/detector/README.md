# detector

(A description)